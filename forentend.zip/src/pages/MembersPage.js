import React from "react";
import MembersTable from "../components/MembersTable";

const MembersPage = () => {
  return (
    <div>
      <MembersTable />
    </div>
  );
};

export default MembersPage;
